/*
 Navicat Premium Dump SQL

 Source Server         : ftwp28-local
 Source Server Type    : MySQL
 Source Server Version : 80029 (8.0.29)
 Source Host           : localhost:3306
 Source Schema         : ftwp28

 Target Server Type    : MySQL
 Target Server Version : 80029 (8.0.29)
 File Encoding         : 65001

 Date: 09/10/2026 16:31:20
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for notdrawn_order_stat
-- ----------------------------
DROP TABLE IF EXISTS `notdrawn_order_stat`;
CREATE TABLE `notdrawn_order_stat`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `game_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'JND',
  `game_issue` varchar(18) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `platform_source` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `large_amount` decimal(10, 2) NULL DEFAULT 0.00,
  `small_amount` decimal(10, 2) NULL DEFAULT 0.00,
  `single_amount` decimal(10, 2) NULL DEFAULT 0.00,
  `double_amount` decimal(10, 2) NULL DEFAULT 0.00,
  `big_single_amount` decimal(10, 2) NULL DEFAULT 0.00,
  `small_double_amount` decimal(10, 2) NULL DEFAULT 0.00,
  `small_single_amount` decimal(10, 2) NULL DEFAULT 0.00,
  `big_double_amount` decimal(10, 2) NULL DEFAULT 0.00,
  `state` int UNSIGNED NOT NULL DEFAULT 0 COMMENT '状态0-未送达；1-送达',
  `msg` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `create_time` datetime NULL DEFAULT NULL,
  `update_time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
